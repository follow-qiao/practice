<?php
header('content-type:text/html;charset=utf-8');

echo "欢迎来到北京妙味课堂！";

?>